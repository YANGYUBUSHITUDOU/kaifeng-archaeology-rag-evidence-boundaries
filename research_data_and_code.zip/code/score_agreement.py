"""Input CSVs blind_id,verdict; only genuinely independent originals qualify."""
import csv,json,sys
from collections import Counter
def read(p):
    rows=list(csv.DictReader(open(p,encoding='utf-8-sig')))
    assert len({r['blind_id'] for r in rows})==len(rows),'duplicate IDs'
    assert all(r['verdict'] in ['correct','partial','wrong'] for r in rows),'missing/invalid score'
    return {r['blind_id']:r['verdict'] for r in rows}
a,b=map(read,sys.argv[1:3]);assert a.keys()==b.keys() and len(a)==36,'need same 36 answers'
n=len(a);agree=sum(a[k]==b[k] for k in a)/n
ca,cb=Counter(a.values()),Counter(b.values());chance=sum(ca[x]*cb[x] for x in ['correct','partial','wrong'])/n**2
kappa=None if chance==1 else (agree-chance)/(1-chance)
print(json.dumps({'n':n,'agreement':agree,'cohen_kappa_unweighted':kappa,'disagreements':[k for k in a if a[k]!=b[k]],'warning':'只能用于先独立后讨论的原始表；κ未定义时不得写作1'},ensure_ascii=False,indent=2))
