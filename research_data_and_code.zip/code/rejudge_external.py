"""Non-OpenAI OpenAI-compatible endpoint adapter; requires local environment credentials."""
import os,json,urllib.request,datetime,hashlib,sys
from pathlib import Path
inp=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
endpoint=os.environ['ALT_JUDGE_URL'];model=os.environ['ALT_JUDGE_MODEL'];key=os.environ['ALT_JUDGE_API_KEY'];provider=os.environ['ALT_JUDGE_PROVIDER']
assert provider.lower() not in ['openai','azure openai','azure'],'must use another provider'
inst='只依据本题证据核对匿名答案，不用外部知识，不猜测方法。输出JSON：blind_id、correctness(2完全正确/1部分正确/0错误)、evidence_support(2充分/1部分/0不足)、unsupported_claim(bool)、note。核心正确但添加无依据事实总体最多1；保留原文观点主体、关系方向、推论限定。拒答但证据可回答为错误。'
meta={'provider':provider,'model_requested':model,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'blind_methods':True}
(out/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
for item in json.loads(inp.read_text()):
    dest=out/(item['blind_id']+'.json')
    if dest.exists():continue
    body={'model':model,'messages':[{'role':'system','content':inst},{'role':'user','content':json.dumps(item,ensure_ascii=False)}],'temperature':0}
    req=urllib.request.Request(endpoint,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=120) as response:raw=json.load(response)
    s=raw['choices'][0]['message']['content'].strip()
    if s.startswith('```'):s='\n'.join(s.splitlines()[1:-1])
    r=json.loads(s);assert r['blind_id']==item['blind_id'] and r['correctness'] in [0,1,2] and r['evidence_support'] in [0,1,2] and type(r['unsupported_claim']) is bool
    dest.write_text(json.dumps({'rating':r,'response_model':raw.get('model'),'response_id':raw.get('id'),'received_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},ensure_ascii=False,indent=2))
meta['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();meta['completed']=len(list(out.glob('J*.json')))
(out/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print(meta['completed'])
