"""Recompute existing machine labels, not regenerate answers. Standard library only."""
import csv,json,random
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'recomputed';OUT.mkdir(exist_ok=True)
def truth(x):return str(x).lower()=='true'
report={}
for name in ['批量','隔离']:
    rows=list(csv.DictReader((ROOT/f'data/{name}逐题匿名评价.csv').open(encoding='utf-8-sig')))
    methods=sorted({r['method'] for r in rows}); keys=[(r['question_id'],r['method'],r['run']) for r in rows]
    assert len(rows)==270 and len(set(keys))==270
    qs=sorted({r['question_id'] for r in rows});assert len(qs)==30
    assert all(len([r for r in rows if r['question_id']==q and r['method']==m])==3 for q in qs for m in methods)
    summaries={m:{'answers':90,'correct':sum(r['verdict']=='correct' for r in rows if r['method']==m),'unsupported':sum(truth(r['unsupported_claim']) for r in rows if r['method']==m)} for m in methods}
    comparisons={}
    for i,a in enumerate(methods):
        for b in methods[i+1:]:
            d=[sum(r['verdict']=='correct' for r in rows if r['method']==a and r['question_id']==q)/3-sum(r['verdict']=='correct' for r in rows if r['method']==b and r['question_id']==q)/3 for q in qs]
            rng=random.Random(20261006 if name=='批量' else 20261007);bs=sorted(sum(rng.choice(d) for _ in d)/30 for _ in range(10000))
            comparisons[f'{a}_minus_{b}']={'difference':sum(d)/30,'percentile95':[bs[249],bs[9749]],'unit':'question','independent_n':30}
    report[name]={'summaries':summaries,'comparisons':comparisons}
expected={'HYBRID':62,'GENERIC':59,'ARCH':61}
assert all(report['隔离']['summaries'][k]['correct']==v for k,v in expected.items())
report['external10']={}
rows=list(csv.DictReader((ROOT/'data/外部10题机器评价90条.csv').open(encoding='utf-8-sig')))
assert len(rows)==90
for m in sorted({r['method'] for r in rows}):
    subset=[r for r in rows if r['method']==m]
    report['external10'][m]={'n':len(subset),'correct':sum(int(r['correctness'])==2 for r in subset),'evidence_support_insufficient':sum(int(r['evidence_support'])<2 for r in subset)}
(OUT/'recomputed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
