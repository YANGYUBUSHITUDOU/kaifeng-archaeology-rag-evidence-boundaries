import csv,json,random
from pathlib import Path
p=Path(__file__).parent
rd=lambda name:list(csv.DictReader((p/name).open(encoding='utf-8-sig')))
main=rd('main30.csv');human=rd('human12.csv');glm=rd('glm_external10.csv')
assert len(main)==270 and len(human)==36 and len(glm)==90
assert len({(r['题号'],r['方法'],r['轮次']) for r in main})==270
assert len({r['blind_id'] for r in glm})==90
result={'main30':{},'human12':{},'glm_external10':{}}
for m in ['HYBRID','GENERIC','ARCH']:
 result['main30'][m]=[sum(int(r['AI证据内合规标签'])==2 for r in main if r['方法']==m and int(r['轮次'])==n) for n in [1,2,3]]
 result['human12'][m]=sum(r['总体判断']=='正确' for r in human if r['方法']==m)
 result['glm_external10'][m]=sum(int(r['correctness'])==2 for r in glm if r['method']==m)
assert result['main30']=={'HYBRID':[29,29,26],'GENERIC':[29,29,29],'ARCH':[30,30,29]}
assert result['human12']=={'HYBRID':9,'GENERIC':11,'ARCH':12}
assert result['glm_external10']=={'HYBRID':28,'GENERIC':27,'ARCH':30}
qs=sorted({r['question_id'] for r in glm});assert len(qs)==10
for m in ['HYBRID','GENERIC']:
 d=[sum(int(r['correctness'])==2 for r in glm if r['question_id']==q and r['method']=='ARCH')/3-sum(int(r['correctness'])==2 for r in glm if r['question_id']==q and r['method']==m)/3 for q in qs]
 rng=random.Random(20261013);b=sorted(sum(rng.choice(d) for _ in qs)/10 for _ in range(10000))
 result['ARCH_minus_'+m]={'difference':sum(d)/10,'descriptive_bootstrap95':[b[249],b[9749]]}
(p/'recomputed_current.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
